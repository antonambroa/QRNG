"""
Copyright (C) 2022 QUSIDE TECHNOLOGIES - All Rights Reserved.

Unauthorized copying of this file, via any medium is strictly prohibited.
"""
import sys
if sys.platform == 'win32':
    from ctypes import c_uint32, c_uint16, POINTER, pointer, windll, c_char_p
else:
    from ctypes import cdll, c_uint32, c_uint16, POINTER, pointer, c_char_p
import numpy as np


class QusideQRNGLALUser:
    """
    Quside QRNG Library Abstract Layer.

    This class is used to request monitors and random numbers from Python through Quside QRNG library.
    """
    def __init__(self, ip=0, lib='libqusideQRNGuser.so'):
        """
        Init the class loading the Quside QRNG library.
        """
        self.c_lib = self.load_library(lib)

        self.devIDs = pointer(c_uint16(0))
        self.numDevs = c_uint16(1)

        self.ip = ip

        if ip != 0:
            self.serverDisconnected = False
            self.connect(ip)

        else:
            self.c_lib.init_library()

            self.c_lib.get_boards(pointer(self.devIDs), pointer(self.numDevs))

    def __del__(self):
        try:
            if self.ip != 0:
                if not self.serverDisconnected:
                    self.disconnect()

            else:
                self.c_lib.free_library()

        except Exception as e:
            print(e)

    @staticmethod
    def load_library(lbr):
        """
        Load C library.

        :param lbr: library name with suffix (*.so or *.dll).
        :return: string with library path.
        """
        try:
            if sys.platform == 'win32':
                lbr = lbr.replace('.so', '.dll')
                pathDLL = \
                    'C:\\Program Files\\Quside Technologies S.L.\\QusideQRNGLibrary\\' + lbr

                return windll.LoadLibrary(pathDLL)

            elif sys.platform == 'linux':
                return cdll.LoadLibrary(lbr)

            else:
                raise Exception('The Quside QRNG LAL is not compatible with this Operating System.')

        except Exception as e:
            print(e)
            sys.exit(-1)

    # region CONNECT/DISCONNECT
    def connect(self, ip):
        try:
            ip = c_char_p(bytes(ip.encode('utf-8')))
            print(ip.value)
            self.c_lib.connectToServer(ip)
            self.serverDisconnected = False

        except Exception as e:
            print(e)

    def disconnect(self):
        try:
            self.c_lib.disconnectServer()
            self.serverDisconnected = True

        except Exception as e:
            print(e)
    # endregion CONNECT/DISCONNECT

    # region BOARD
    def find_boards(self):
        """
        Search Babylon devices connected in the system and initialize
        the lists with the descriptors. THIS IS ONLY USED BY PCIe.

        :return: number of Babylons connected.
        """
        return self.c_lib.find_boards()

    def get_boards(self):
        """
        Returns a list of the devices IDs connected to the system.
        THIS IS ONLY USED BY PCIe.

        :return: List that will contain the devices IDs and
                 number of elements that the list will contain.
        """
        self.c_lib.get_boards(pointer(self.devIDs), pointer(self.numDevs))

        return np.array(np.fromiter(self.devIDs, dtype=np.int16, count=self.numDevs.value)), self.numDevs.value

    def find_device(self, devID):
        """
        Returns the index of a device contained in the devices list.

        :param devID: Device id to search in the list.
        :return: The index of the devID in the devices list. If the provided
        devID does not exist, this function will return a -1.
        """
        return self.c_lib.find_device(c_uint16(devID))
    # endregion BOARD

    # region CAPTURE
    def get_random(self, num_bytes, devInd):
        """
        Get extracted random numbers.

        :param num_bytes: number of bytes to request.
        :param devInd: index of the device.
        :return: numpy array with the extracted random numbers.
        """
        try:
            mem_slot = np.zeros(int(num_bytes / 4), dtype=np.uint32)

            if self.c_lib.get_random(mem_slot.ctypes.data_as(POINTER(c_uint32)),
                                     c_uint32(num_bytes), c_uint16(devInd)) < 0:
                raise Exception('PCIe error reading.')

            else:
                return mem_slot

        except Exception as e:
            print(e)

    def get_raw(self, num_bytes, devInd):
        """
        Get raw random numbers.

        :param num_bytes: number of bytes to request.
        :param devInd: index of the device.
        :return: numpy array with the raw random numbers.
        """
        try:
            mem_slot = np.zeros(int(num_bytes / 4), dtype=np.uint32)

            if self.c_lib.get_raw(mem_slot.ctypes.data_as(POINTER(c_uint32)),
                                  c_uint32(num_bytes), c_uint16(devInd)) < 0:
                raise Exception('PCIe error reading.')

            else:
                return mem_slot

        except Exception as e:
            print(e)
    # endregion CAPTURE
